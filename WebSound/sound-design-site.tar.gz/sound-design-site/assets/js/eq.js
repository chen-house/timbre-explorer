/* ============================================
   EQ 互动逻辑
   ============================================ */

let ac = null;
let sourceNode = null;
let filterNode = null;
let gainNode = null;
let playing = false;
let eqOn = true;
let srcType = 'pink';

function getAC() {
  if (!ac) ac = new (window.AudioContext || window.webkitAudioContext)();
  if (ac.state === 'suspended') ac.resume();
  return ac;
}

/* 生成噪声/合成器素材 */
function buildBuffer(durationSec, type) {
  const a = getAC();
  const len = Math.floor(a.sampleRate * durationSec);
  const buf = a.createBuffer(1, len, a.sampleRate);
  const d = buf.getChannelData(0);

  if (type === 'pink') {
    // Paul Kellet 粉噪声算法
    let b0 = 0, b1 = 0, b2 = 0, b3 = 0, b4 = 0, b5 = 0, b6 = 0;
    for (let i = 0; i < len; i++) {
      const w = Math.random() * 2 - 1;
      b0 = 0.99886 * b0 + w * 0.0555179;
      b1 = 0.99332 * b1 + w * 0.0750759;
      b2 = 0.96900 * b2 + w * 0.1538520;
      b3 = 0.86650 * b3 + w * 0.3104856;
      b4 = 0.55000 * b4 + w * 0.5329522;
      b5 = -0.7616 * b5 - w * 0.0168980;
      d[i] = (b0 + b1 + b2 + b3 + b4 + b5 + b6 + w * 0.5362) * 0.11;
      b6 = w * 0.115926;
    }
  } else {
    // Am 类和弦 (A3-C4-E4-A4)
    const freqs = [220, 261.63, 329.63, 440];
    for (let i = 0; i < len; i++) {
      const t = i / a.sampleRate;
      let s = 0;
      freqs.forEach((f, idx) => {
        s += Math.sin(2 * Math.PI * f * t) / (idx + 1.5);
      });
      const env = Math.exp(-t * 0.4) * (1 - Math.exp(-t * 30));
      d[i] = s * 0.18 * env;
    }
  }
  return buf;
}

function stopAll() {
  if (sourceNode) {
    try { sourceNode.stop(); } catch (e) {}
    sourceNode = null;
  }
  playing = false;
  document.getElementById('main-play').classList.remove('playing');
  document.getElementById('play-icon').innerHTML = '<polygon points="3,2 12,7 3,12"/>';
  document.getElementById('play-status').textContent = '点击播放';
}

function togglePlay() {
  if (playing) { stopAll(); return; }
  const a = getAC();
  const dur = srcType === 'pink' ? 4 : 3.5;
  const buf = buildBuffer(dur, srcType);

  filterNode = a.createBiquadFilter();
  filterNode.type = 'peaking';
  filterNode.frequency.value = parseFloat(document.getElementById('sl-freq').value);
  filterNode.gain.value = eqOn ? parseFloat(document.getElementById('sl-gain').value) : 0;
  filterNode.Q.value = parseFloat(document.getElementById('sl-q').value);

  gainNode = a.createGain();
  gainNode.gain.value = 0.55;

  sourceNode = a.createBufferSource();
  sourceNode.buffer = buf;
  sourceNode.loop = (srcType === 'pink');

  sourceNode.connect(filterNode);
  filterNode.connect(gainNode);
  gainNode.connect(a.destination);
  sourceNode.start();

  playing = true;
  document.getElementById('main-play').classList.add('playing');
  document.getElementById('play-icon').innerHTML = '<rect x="3" y="2" width="3" height="10" rx="1"/><rect x="9" y="2" width="3" height="10" rx="1"/>';
  document.getElementById('play-status').textContent = '播放中 — 调节参数实时听变化';

  if (!sourceNode.loop) {
    sourceNode.onended = () => {
      playing = false;
      document.getElementById('main-play').classList.remove('playing');
      document.getElementById('play-icon').innerHTML = '<polygon points="3,2 12,7 3,12"/>';
      document.getElementById('play-status').textContent = '点击重新播放';
    };
  }
}

function setSource(t) {
  srcType = t;
  const wasPlaying = playing;
  stopAll();
  document.querySelectorAll('[data-source]').forEach(b => {
    b.classList.toggle('active', b.dataset.source === t);
  });
  if (wasPlaying) setTimeout(togglePlay, 50);
}

function toggleEQ() {
  eqOn = !eqOn;
  const btn = document.getElementById('eq-toggle');
  btn.textContent = 'EQ: ' + (eqOn ? '开' : '关');
  btn.classList.toggle('active', eqOn);
  if (filterNode) {
    filterNode.gain.value = eqOn ? parseFloat(document.getElementById('sl-gain').value) : 0;
  }
  drawEQ();
}

function updateEQ() {
  const freq = parseFloat(document.getElementById('sl-freq').value);
  const gain = parseFloat(document.getElementById('sl-gain').value);
  const q = parseFloat(document.getElementById('sl-q').value);

  document.getElementById('v-freq').textContent =
    freq >= 1000 ? (freq / 1000).toFixed(1) + ' kHz' : Math.round(freq) + ' Hz';
  document.getElementById('v-gain').textContent =
    (gain >= 0 ? '+' : '') + gain.toFixed(1) + ' dB';
  document.getElementById('v-q').textContent = q.toFixed(1);

  if (filterNode) {
    filterNode.frequency.value = freq;
    filterNode.gain.value = eqOn ? gain : 0;
    filterNode.Q.value = q;
  }
  drawEQ();
}

function applyPreset(preset) {
  const presets = {
    scan:  { freq: 1000, gain: 10, q: 8,
             status: '扫频模式：增益 +10 dB、极窄 Q。慢慢移动频率，最难听处即问题频率，再翻负值衰减。' },
    phone: { freq: 900, gain: 0, q: 0.4,
             status: '电话声参考位（实际操作应组合 HPF 300 Hz + LPF 3.4 kHz，这里用宽 Q 做近似演示）。' },
    air:   { freq: 12000, gain: 6, q: 0.7,
             status: '空气感：12 kHz 附近 High Shelf 提升，常用于人声"开阔感"和亲密感。' },
    mud:   { freq: 300, gain: -5, q: 1.2,
             status: '去泥浊：250–500 Hz 是混音"浑浊区"，多轨在此堆积，削减后整体立刻通透。' },
    reset: { freq: 1000, gain: 0, q: 1.4,
             status: '已重置 — 零增益状态。' },
  };
  const p = presets[preset];
  if (!p) return;
  document.getElementById('sl-freq').value = p.freq;
  document.getElementById('sl-gain').value = p.gain;
  document.getElementById('sl-q').value = p.q;
  document.getElementById('preset-status').textContent = p.status;
  updateEQ();
}

/* EQ 曲线绘制 */
function drawEQ() {
  const canvas = document.getElementById('eq-canvas');
  if (!canvas) return;
  const dpr = window.devicePixelRatio || 1;
  const rect = canvas.getBoundingClientRect();
  canvas.width = rect.width * dpr;
  canvas.height = rect.height * dpr;
  const ctx = canvas.getContext('2d');
  ctx.scale(dpr, dpr);
  const W = rect.width, H = rect.height;

  ctx.fillStyle = '#0F0E0C';
  ctx.fillRect(0, 0, W, H);

  const freqToX = f => (Math.log10(f) - Math.log10(20)) / (Math.log10(20000) - Math.log10(20)) * W;
  const dBToY = g => H / 2 - (g / 15) * (H / 2 - 18);

  // 网格
  ctx.strokeStyle = 'rgba(255,255,255,0.06)';
  ctx.lineWidth = 0.5;
  [50, 100, 200, 500, 1000, 2000, 5000, 10000, 20000].forEach(f => {
    const x = freqToX(f);
    ctx.beginPath();
    ctx.moveTo(x, 0); ctx.lineTo(x, H);
    ctx.stroke();
  });
  [12, 6, -6, -12].forEach(g => {
    const y = dBToY(g);
    ctx.beginPath();
    ctx.moveTo(0, y); ctx.lineTo(W, y);
    ctx.stroke();
  });

  // 0 dB 虚线
  ctx.strokeStyle = 'rgba(255,255,255,0.18)';
  ctx.setLineDash([3, 4]);
  ctx.beginPath();
  ctx.moveTo(0, H / 2); ctx.lineTo(W, H / 2);
  ctx.stroke();
  ctx.setLineDash([]);

  // 曲线
  const freq = parseFloat(document.getElementById('sl-freq').value);
  const gain = eqOn ? parseFloat(document.getElementById('sl-gain').value) : 0;
  const Q = parseFloat(document.getElementById('sl-q').value);

  const N = 400;
  const pts = [];
  for (let i = 0; i <= N; i++) {
    const f = Math.pow(10, Math.log10(20) + (Math.log10(20000) - Math.log10(20)) * (i / N));
    const w = f / freq;
    const dB = gain / (1 + Q * Q * (w - 1 / w) * (w - 1 / w));
    pts.push({ x: freqToX(f), y: dBToY(dB) });
  }

  // 填充
  ctx.beginPath();
  pts.forEach((p, i) => i === 0 ? ctx.moveTo(p.x, p.y) : ctx.lineTo(p.x, p.y));
  ctx.lineTo(W, H);
  ctx.lineTo(0, H);
  ctx.closePath();
  const grad = ctx.createLinearGradient(0, 0, 0, H);
  grad.addColorStop(0, 'rgba(216,90,48,0.25)');
  grad.addColorStop(1, 'rgba(216,90,48,0)');
  ctx.fillStyle = grad;
  ctx.fill();

  // 主曲线
  ctx.beginPath();
  pts.forEach((p, i) => i === 0 ? ctx.moveTo(p.x, p.y) : ctx.lineTo(p.x, p.y));
  ctx.strokeStyle = eqOn ? '#D85A30' : 'rgba(216,90,48,0.4)';
  ctx.lineWidth = 2.5;
  ctx.stroke();

  // 控制点
  ctx.beginPath();
  ctx.arc(freqToX(freq), dBToY(gain), 6, 0, Math.PI * 2);
  ctx.fillStyle = eqOn ? '#D85A30' : 'rgba(216,90,48,0.4)';
  ctx.fill();
  ctx.strokeStyle = 'rgba(247,243,236,0.95)';
  ctx.lineWidth = 1.5;
  ctx.stroke();

  // 频率标签
  ctx.fillStyle = 'rgba(255,255,255,0.32)';
  ctx.font = '10px ui-monospace, monospace';
  [{ f: 20, l: '20' }, { f: 100, l: '100' }, { f: 1000, l: '1k' },
   { f: 5000, l: '5k' }, { f: 20000, l: '20k' }].forEach(({ f, l }) => {
    ctx.fillText(l, freqToX(f) - 8, H - 5);
  });

  // 增益标签
  [['+12', 12], ['+6', 6], ['0', 0], ['-6', -6], ['-12', -12]].forEach(([l, g]) => {
    ctx.fillText(l, 4, dBToY(g) + 3);
  });
}

/* 电话频谱图 */
function drawPhoneSpectrum() {
  const cv = document.getElementById('phone-canvas');
  if (!cv) return;
  const dpr = window.devicePixelRatio || 1;
  const rect = cv.getBoundingClientRect();
  cv.width = rect.width * dpr;
  cv.height = rect.height * dpr;
  const c = cv.getContext('2d');
  c.scale(dpr, dpr);
  const W = rect.width, H = rect.height;

  c.fillStyle = '#FAFAF7';
  c.fillRect(0, 0, W, H);

  const freqToX = f => (Math.log10(f) - Math.log10(20)) / (Math.log10(20000) - Math.log10(20)) * W;
  const x300 = freqToX(300);
  const x3400 = freqToX(3400);

  // 高亮电话保留区域
  c.fillStyle = 'rgba(216, 90, 48, 0.12)';
  c.fillRect(x300, 0, x3400 - x300, H);

  // 边界线
  c.strokeStyle = '#D85A30';
  c.lineWidth = 1.2;
  c.setLineDash([4, 3]);
  c.beginPath(); c.moveTo(x300, 8); c.lineTo(x300, H - 18); c.stroke();
  c.beginPath(); c.moveTo(x3400, 8); c.lineTo(x3400, H - 18); c.stroke();
  c.setLineDash([]);

  // 频谱 bars
  const n = 70;
  const seedRand = (i) => ((Math.sin(i * 12.9898) * 43758.5453) % 1 + 1) % 1;
  for (let i = 0; i < n; i++) {
    const f = Math.pow(10, Math.log10(20) + (Math.log10(20000) - Math.log10(20)) * i / (n - 1));
    const x = freqToX(f);
    const inPhone = f >= 300 && f <= 3400;
    const baseH = inPhone ? (22 + seedRand(i) * 38) : (4 + seedRand(i) * 10);
    c.fillStyle = inPhone ? '#D85A30' : 'rgba(44, 42, 30, 0.18)';
    c.fillRect(x - 3, H / 2 - baseH / 2, 5, baseH);
  }

  // 标签
  c.fillStyle = '#993C1D';
  c.font = '500 11px sans-serif';
  c.fillText('300 Hz', x300 + 4, 18);
  c.fillText('3.4 kHz', x3400 - 50, 18);

  // x 轴
  c.fillStyle = 'rgba(44, 42, 30, 0.4)';
  c.font = '10px ui-monospace, monospace';
  [20, 100, 1000, 10000, 20000].forEach(f => {
    const l = f >= 1000 ? f / 1000 + 'k' : f.toString();
    c.fillText(l, freqToX(f) - 8, H - 4);
  });
}

/* 六种 EQ 形状 SVG 生成 */
function renderShapes() {
  const shapes = [
    { name: 'Bell 钟形', sub: '最常用 — 任意频段提升或衰减',
      d: 'M 5 32 L 70 32 Q 90 32 100 8 Q 110 32 130 32 L 195 32', color: '#D85A30' },
    { name: 'Notch 陷波', sub: '窄而深的衰减，灭单一啸叫',
      d: 'M 5 32 L 85 32 Q 95 32 100 56 Q 105 32 115 32 L 195 32', color: '#D85A30' },
    { name: 'High-Pass 高通', sub: '切低频 — 去掉空调嗡嗡声',
      d: 'M 5 56 L 60 56 Q 75 56 90 32 Q 105 8 130 8 L 195 8', color: '#1D9E75' },
    { name: 'Low-Pass 低通', sub: '切高频 — 制造"闷"和"远"',
      d: 'M 5 8 L 70 8 Q 95 8 110 32 Q 125 56 140 56 L 195 56', color: '#1D9E75' },
    { name: 'Low Shelf 低架', sub: '整个低频区抬升或下压',
      d: 'M 5 14 L 50 14 Q 70 14 85 32 L 195 32', color: '#7B5EA7' },
    { name: 'High Shelf 高架', sub: '整个高频区加亮或变暗',
      d: 'M 5 32 L 110 32 Q 130 32 145 14 L 195 14', color: '#7B5EA7' },
  ];

  const grid = document.getElementById('shapes-grid');
  if (!grid) return;
  shapes.forEach(s => {
    const card = document.createElement('div');
    card.className = 'shape-card';
    card.innerHTML = `
      <div class="shape-svg-wrap">
        <svg width="100%" height="100%" viewBox="0 0 200 64" xmlns="http://www.w3.org/2000/svg">
          <line x1="5" y1="32" x2="195" y2="32" stroke="rgba(44,42,30,0.12)" stroke-width="0.8" stroke-dasharray="2 3"/>
          <path d="${s.d}" stroke="${s.color}" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" fill="none"/>
        </svg>
      </div>
      <div class="shape-name">${s.name}</div>
      <div class="shape-sub">${s.sub}</div>
    `;
    grid.appendChild(card);
  });
}

/* 初始化 */
window.addEventListener('DOMContentLoaded', () => {
  renderShapes();
  setTimeout(() => {
    drawEQ();
    drawPhoneSpectrum();
  }, 50);

  window.addEventListener('resize', () => {
    drawEQ();
    drawPhoneSpectrum();
  });
});
